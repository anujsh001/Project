package com.chatapp.dto;

public class UserDTO {
  
	 private String userid;
	 private char[] pasaword;
	 
	 public UserDTO(String userid, char[] password) {
		 this.setUserid(userid);
		 this.setPasaword(password);
	 }

	

	public String getUserid() {
		return userid;
	}

	public void setUserid(String userid) {
		this.userid = userid;
	}
	public char[] getPasaword() {
		return pasaword;
	}

	public void setPasaword(char[] pasaword) {
		this.pasaword = pasaword;
	}
}
