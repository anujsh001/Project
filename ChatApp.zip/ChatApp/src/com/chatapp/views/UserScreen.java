package com.chatapp.views;

import javax.swing.JFrame;
import java.awt.Color;
import javax.swing.JLabel;
import javax.swing.JOptionPane;
import javax.swing.SwingConstants;
import java.awt.Font;
import javax.swing.JTextField;
import javax.swing.JPasswordField;
import javax.swing.JButton;
import java.awt.event.ActionListener;
import java.sql.SQLException;
import java.awt.event.ActionEvent;
import com.chatapp.dao.UserDAO;
import com.chatapp.dto.UserDTO;
public class UserScreen extends JFrame {
	private JTextField useridtxt;
	private JPasswordField passwordField;

	
	public static void main(String[] args) {
		
		UserScreen window = new UserScreen();
					
				

	}
	UserDAO userDAO = new UserDAO();
	   private void doLogin() {
		   String userid =useridtxt.getText();
    	   char [] password = passwordField.getPassword();
    	   
    	   UserDTO userDTO = new UserDTO(userid, password); 
    	   try {
    		   String message = "";
			if(userDAO.isLogin(userDTO)) {
				message = "welcome " + userid;
				JOptionPane.showConfirmDialog(this, message); 
				setVisible(false);
				dispose();
				DashBoard dashBoard = new DashBoard(message);
				dashBoard.setVisible(true);
			}
			else {
				     message="Invalid Userid or Password";
				     JOptionPane.showConfirmDialog(this, message); 
			}
			
		} catch (ClassNotFoundException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} catch (Exception e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		}
       private void register() {
    	   String userid =useridtxt.getText();
    	   char [] password = passwordField.getPassword();
//    	   UserDAO userDAO = new UserDAO();
    	   UserDTO userDTO = new UserDTO(userid, password); 
    	   try { 
    	   int result = userDAO.add(userDTO);
    	   if(result>0) {
    		   JOptionPane.showMessageDialog(this, "Register successfully");
//    		   System.err.println("Recorded added....");
    	   }
    	   else {
    		   JOptionPane.showMessageDialog(this, "Register Fail");
    	   }
    	   }
    	   catch(ClassNotFoundException| SQLException ex ) {
    		   System.err.println("DB Issue.....");
    		   ex.printStackTrace();
    	   }
    	   catch(Exception ex) {
    		   System.err.println("Some Genric Exception Rasied..");
    		   ex.printStackTrace();
    	   }
    	   System.out.println(" userid " +userid+" password "+ password);  //ClassName@HashCode(Hexa)
       }
	/**
	 * Create the application.
	 */
	public UserScreen() {
		setResizable(false);
		setTitle("LOGIN");
		getContentPane().setBackground(new Color(238, 238, 238));
		getContentPane().setForeground(new Color(0, 0, 0));
		
		getContentPane().setLayout(null);
		
		JLabel lblNewLabel = new JLabel("LOGIN");
		lblNewLabel.setFont(new Font("Lucida Grande", Font.BOLD, 40));
		lblNewLabel.setHorizontalAlignment(SwingConstants.CENTER);
		lblNewLabel.setBounds(249, 32, 130, 42);
		getContentPane().add(lblNewLabel);
		
		useridtxt = new JTextField();
		useridtxt.setBounds(330, 106, 211, 42);
		getContentPane().add(useridtxt);
		useridtxt.setColumns(10);
		
		JLabel useridlbl = new JLabel("Userid");
		useridlbl.setFont(new Font("Lucida Grande", Font.PLAIN, 20));
		useridlbl.setHorizontalAlignment(SwingConstants.CENTER);
		useridlbl.setBounds(145, 119, 92, 16);
		getContentPane().add(useridlbl);
		
		JLabel pwdlbl = new JLabel("password");
		pwdlbl.setHorizontalAlignment(SwingConstants.CENTER);
		pwdlbl.setFont(new Font("Lucida Grande", Font.PLAIN, 20));
		pwdlbl.setBounds(145, 196, 105, 25);
		getContentPane().add(pwdlbl);
		
		passwordField = new JPasswordField();
		passwordField.setBounds(333, 196, 208, 34);
		getContentPane().add(passwordField);
		
		JButton loginbt = new JButton("Login");
		loginbt.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				doLogin();
			}
		});
		loginbt.setBounds(186, 277, 117, 29);
		getContentPane().add(loginbt);
		
		JButton registerbt = new JButton("Register");
		registerbt.addActionListener(new ActionListener() {
			@Override
			public void actionPerformed(ActionEvent e) {
				register();
			}
		});
		registerbt.setBounds(349, 277, 117, 29);
		getContentPane().add(registerbt);
		setBackground(new Color(238, 238, 238));
		setSize( 629, 374);
		setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		setLocationRelativeTo(null);
		setVisible(true);
		
	}
}
