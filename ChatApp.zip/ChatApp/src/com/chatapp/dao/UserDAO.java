package com.chatapp.dao;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import com.chatapp.dto.UserDTO;
import com.chatapp.utils.Encryption;

// USER - CRUD(creat read update delet)
public class UserDAO {
	public boolean isLogin(UserDTO userDTO) throws SQLException, ClassNotFoundException, Exception {
		Connection con = null;
		PreparedStatement pstmt = null; 
		ResultSet rs = null;
		final String SQL = "select userid from users where userid=? and password=? ";
		
		try {
			con = CommanDAO.creatConnection();
			pstmt = con.prepareStatement(SQL);
			pstmt.setString(1, userDTO.getUserid());
			String encryptedpwd = Encryption.passwordEncrypt(new String (userDTO.getPasaword()));
			pstmt.setString(2, encryptedpwd);
			rs =pstmt.executeQuery();
			return rs.next();
//			if (rs.next()) {
//				return true; 
//			}
//			else {
//				return false;
//			}
		}
		finally {
			if(rs!=null) {
				rs.close();
			}
			if(pstmt != null) {
				pstmt.close();
			}
			if(con != null) {
				con.close();
			}
		}
	}
   
	//public int add(String userid, String password, String age, String city, String phone, String Email, String stdCode);
	public int add(UserDTO userDTO) throws ClassNotFoundException, SQLException, Exception {
		System.out.println(" Rec " +userDTO.getUserid()+""+userDTO.getPasaword());
		Connection connection = null ;
		Statement stmt = null ; //query
		try {
		connection = CommanDAO.creatConnection();// step-1 connection create
		// step -2 we do a query
		stmt  = connection.createStatement();
		//insert into users (userid , password ) values ('anuj','anuj1234');
		int record =stmt.executeUpdate("insert into users (userid, password) values('"+userDTO.getUserid()+"','"+Encryption.passwordEncrypt(new String( userDTO.getPasaword()))+"')");
		return record;
		}
		finally{// Always execute (Resource	
			if(stmt != null) {
		stmt.close();
			}
			if(connection != null) {
		connection.close();
			}
		}
		
	}
}
