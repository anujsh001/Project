package com.chatapp.network;
import java.io.IOException;
import java.net.ServerSocket;
import java.net.Socket;
import java.util.ArrayList;

import com.chatapp.utils.ConfigReader;

public class Server {
	ServerSocket serverSocket;
	ArrayList<ServerWorker> workers = new ArrayList<>();
	public Server() throws IOException {
		int PORT = Integer.parseInt(ConfigReader.getValue("PORTNO"));
		serverSocket = new ServerSocket(PORT);
		System.out.println("Server Start and Wating For the Clients to joine...");
		henldleClientRequest();
	}
	// Multipte Client HeadShaking
	public void henldleClientRequest() throws IOException {
		while(true) {
			Socket clientSocket =serverSocket.accept(); // HeadShaking
			// per Client per Thread
			ServerWorker serverWorker = new ServerWorker(clientSocket,this);// Creating a new worker/Thread
			workers.add(serverWorker);
			serverWorker.start();
			}
	}
	
	/* Singel Client */
	/*
	public Server() throws IOException  {
		 int PORT = Integer.parseInt(ConfigReader.getValue("PORTNO"));
		serverSocket = new ServerSocket(PORT);
		System.out.println("Server Started and Wating for Client Connection..");
		Socket socket =serverSocket.accept();//
		System.out.println("Client Joine The Server...");
		InputStream in=socket.getInputStream();// read Bytes from the Network
		byte arr[] =in.readAllBytes();
		String str = new String(arr);// convert byte to String
		System.out.println("Message Rec for the Client "+str);
		in.close();
		socket.close();
	}*/

	public static void main(String[] args) throws IOException {
		Server server = new Server();

	}

}
