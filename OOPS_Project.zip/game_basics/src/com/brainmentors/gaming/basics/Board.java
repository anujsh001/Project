package com.brainmentors.gaming.basics;

import java.awt.Color;
import java.awt.Font;
import java.awt.Graphics;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.event.KeyEvent;
import java.awt.event.KeyListener;
import java.awt.image.BufferedImage;

import javax.imageio.ImageIO;
import javax.swing.JPanel;
import javax.swing.Timer;

import com.brainmentors.gaming.settings.GameConstants;
import com.brainmentors.gaming.sprites.KenPlayer;
import com.brainmentors.gaming.sprites.Power;
import com.brainmentors.gaming.sprites.RyuPlayer;

import jaco.mp3.player.MP3Player;




public class Board extends JPanel implements GameConstants, ActionListener, KeyListener{
	BufferedImage backgroundImage;
	RyuPlayer  ryu;
	KenPlayer  ken;
	Timer timer;
	MP3Player player;
	Power player1Power;
	Power player2Power;
	boolean isGameOver ;
	public Board() throws Exception {		
		setBackground(Color.BLACK);
		loadBackGround();
		ryu = new RyuPlayer();
		ken = new KenPlayer();
		setFocusable(true);
		bindEvents();
		gameLoop();
		player = new MP3Player(Board.class.getResource("music.mp3"));
		
		player.setRepeat(true);
		playBackGroundMusic();
		player1Power = new Power(20,"RYU...");
		player2Power = new Power(BOARD_WIDTH/2+200,"KEN...");
	}
	
	public void drawPower(Graphics g) {
		player1Power.draw(g);
		player2Power.draw(g);
	}
	
	void playBackGroundMusic() {
		player.play();
	}
	
	
	
	void bindEvents() {
		this.addKeyListener(this);
	}
	
	void gameLoop() {
		timer = new Timer(DELAY, this);
		timer.start();
	}
	
	void loadBackGround() throws Exception {
		backgroundImage = ImageIO.read(Board.class.getResource("bg.jpeg"));
	}
	
	
	@Override
	protected void paintComponent(Graphics pen) {
		super.paintComponent(pen);
		pen.drawImage(backgroundImage,0,0,BOARD_WIDTH, BOARD_HEIGHT, null);
		ryu.draw(pen);
		ken.draw(pen);
		drawPower(pen);
		playerAttackHit();
		displayMessage(pen);
	}

	@Override
	public void actionPerformed(ActionEvent e) {
		ryu.fall();
		repaint();
		
	}

	@Override
	public void keyTyped(KeyEvent e) {
				
	}
	
	public void displayMessage(Graphics pen) {
		if(isGameOver) {
			pen.setFont(new Font("Chiller", Font.ITALIC, 100));
			pen.setColor(Color.RED);
			pen.drawString("Game Over....",500,400);
			
			timer.stop();
		}

	}
	
	public boolean playerAttackHit() {
		if(isCollide()) {
		if(ryu.isAttacking()) {
			ken.setAction(HIT);
			ken.setPower(ken.getPower()-10);
			player2Power.setW(player2Power.getW()-10);
			
		}
		else if(ken.isAttacking()) {
			ryu.setAction(HIT);
			ryu.setPower(ryu.getPower()-10);
			player1Power.setW(player1Power.getW()-10);
			
		}
		else if (ryu.isAttacking() && ken.isAttacking()) {
			ryu.setAction(HIT);
			ken.setAction(HIT);
			ken.setPower(ken.getPower()-10);
			player2Power.setW(player2Power.getW()-10);
			ryu.setPower(ryu.getPower()-10);
			player1Power.setW(player1Power.getW()-10);
		}
		if(ryu.getPower()<=0 || ken.getPower()<=0) {
			isGameOver = true;
		}
		return true;
		}
		return false;
	}
	
	public boolean isCollide() {
		
		int xDistance = Math.abs(ryu.getX() - ken.getX());
		int yDistance = Math.abs(ryu.getY() - ken.getY());
		int maxH = Math.max(ryu.getH(), ken.getH());
		int maxW = Math.max(ryu.getW(), ken.getW());
		return xDistance<=maxW-50 && yDistance<=maxH;
	}
	
	

	@Override
	public void keyPressed(KeyEvent e) {
		if(e.getKeyCode() == KeyEvent.VK_J) {
			ken.setAction(KICK);
			ken.setAttacking(true);
		}
		if(e.getKeyCode()==KeyEvent.VK_K) {
			ryu.setAction(KICK);
			ryu.setAttacking(true);
		}
		else if(e.getKeyCode()==KeyEvent.VK_P) {
			ryu.setAction(PUNCH);
			ryu.setAttacking(true);
		}
		else if(e.getKeyCode()==KeyEvent.VK_O) {
			ken.setAction(PUNCH);
			ken.setAttacking(true);
		}
		else if (e.getKeyCode()== KeyEvent.VK_RIGHT) {
			ryu.setSpeed(SPEED);
			ryu.move();
		}
		else if (e.getKeyCode()== KeyEvent.VK_L) {
			ken.setSpeed(SPEED * -1);
			ken.move();
		}
		else if (e.getKeyCode() == KeyEvent.VK_LEFT) {
			ryu.setSpeed(SPEED * -1);
			ryu.move();
		}
		else if(e.getKeyCode() == KeyEvent.VK_UP) {
			ryu.jump();
		}
		
	}

	@Override
	public void keyReleased(KeyEvent e) {
				
	}

}

