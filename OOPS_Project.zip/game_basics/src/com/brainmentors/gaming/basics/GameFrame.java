package com.brainmentors.gaming.basics;

import javax.imageio.ImageIO;
import javax.swing.ImageIcon;
import javax.swing.JFrame;

import com.brainmentors.gaming.settings.GameConstants;

public class GameFrame extends JFrame implements GameConstants {
	public GameFrame() throws Exception {
		setDefaultCloseOperation(EXIT_ON_CLOSE);
		setSize(BOARD_WIDTH, BOARD_HEIGHT);
		setResizable(false);
		setLocationRelativeTo(null);
		setTitle("Street Fighter..");
		ImageIcon image = new ImageIcon("logo.png");
		setIconImage(image.getImage());
		Board board = new Board();
		add(board);
		setVisible(true);
	}
	
	
	
	public static void main(String[] args) {
		
		try {
			GameFrame obj = new GameFrame();
		} catch (Exception e) {
			e.printStackTrace();
		}
		
		
	}
}

