package com.brainmentors.gaming.settings;

public interface GameConstants {
	
	int BOARD_WIDTH = 1500; 
	int BOARD_HEIGHT = 850;
	int FLOOR = BOARD_HEIGHT - 150;
	String PLAYER_IMAGE = "player-sprite.gif";
	String KEN_IMAGE = "kenimage.png";
	int DELAY = 70;
	int DEFAULT_MOVE = 1;
	int KICK = 2;
	int HIT = 0;
	int PUNCH = 3;
	int SPEED = 20;
	int FORCE = -30;
	int GRAVITY = 4;
	
	int MAX_POWER = 500;
}

