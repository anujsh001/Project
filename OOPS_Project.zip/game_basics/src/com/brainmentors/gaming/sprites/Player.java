package com.brainmentors.gaming.sprites;

import java.awt.Graphics;
import java.awt.image.BufferedImage;

import javax.imageio.ImageIO;

import com.brainmentors.gaming.settings.GameConstants;

public abstract class Player implements GameConstants {
	protected int x;
	

	protected int y;
	protected int w;
	
	protected int power;

	protected int h;
	protected int speed;
	protected int action;
	protected boolean isJumping ;
	final int TOTAL_MOVES = 6;
	protected BufferedImage fullImage;
	BufferedImage defaultMove [] = new BufferedImage[TOTAL_MOVES];
	BufferedImage kick [] = new BufferedImage[TOTAL_MOVES];
	BufferedImage punch [] = new BufferedImage[TOTAL_MOVES];
	BufferedImage currentMoves [] = new BufferedImage[TOTAL_MOVES];
	BufferedImage hitMove [] = new BufferedImage[TOTAL_MOVES];
	protected int currentForce;
	protected boolean isAttacking ;
	public Player(String imageName) throws Exception {
		power = MAX_POWER;
		isJumping = false;
		
		h = w = 200;
		y = FLOOR - h;
		speed = SPEED;
		action = DEFAULT_MOVE;
		fullImage = ImageIO.read(Player.class.getResource(imageName));
		isAttacking = false;
		defaultAction();
		kickAction();
		punchAction();
		hit();
		
	
	
	}
	protected abstract void punchAction();
	protected abstract void defaultAction();
	protected abstract void kickAction();
	protected abstract void hit();
	
	
	public int getPower() {
		return power;
	}
	public void setPower(int power) {
		this.power = power;
	}
	public int getX() {
		return x;
	}
	public void setX(int x) {
		this.x = x;
	}
	public int getY() {
		return y;
	}
	public void setY(int y) {
		this.y = y;
	}
	public int getW() {
		return w;
	}
	public void setW(int w) {
		this.w = w;
	}
	public int getH() {
		return h;
	}
	public void setH(int h) {
		this.h = h;
	}
	
	
	
	public boolean isAttacking() {
		return isAttacking;
	}
	public void setAttacking(boolean isAttacking) {
		this.isAttacking = isAttacking;
	}
	public void fall() {
		if(y>=FLOOR-h) {
			isJumping =false;
			return ;
		}
		currentForce = currentForce + GRAVITY;
		y = y + currentForce;
	}
	
	public void jump() {
		if(!isJumping) {
		currentForce = FORCE;
		y = y + FORCE;
		isJumping = true;
		}
	}
	
	
	public int getSpeed() {
		return speed;
	}


	public void setSpeed(int speed) {
		this.speed = speed;
	}


	public void move() {
		x = x + speed;
	}
	
	public void setAction(int action) {
		
		this.action = action;
	}
	
		int index = 0;
	
	protected void printCurrentMove(Graphics g) {
		if(index>5) {
			index = 0;
			action = DEFAULT_MOVE;
			isAttacking = false;
		}
		g.drawImage(currentMoves[index],x,y,w,h,null);
		index++;
	}
	
	
	
	public void draw(Graphics g) {
		if(action == DEFAULT_MOVE) {
			currentMoves = defaultMove;
		}
		else if (action == PUNCH) {
			currentMoves = punch;
		}
		else if (action == KICK) {
			currentMoves = kick;
		}
		else if (action ==HIT) {
			currentMoves = hitMove;
		}
		printCurrentMove(g);
	}
	
	

}

